﻿namespace Application.Users.Exceptions;

public abstract class UserException(string message, Exception? innerException = null)
    : Exception(message, innerException);

public class UserNotFoundException(string identifier)
    : UserException($"User not found: {identifier}");

public class UnauthorizedUserAccessException()
    : UserException("User is not authorized to perform this action");

public class InvalidRoleException(string role)
    : UserException($"Invalid role: {role}");

public class UnhandledUserException(Exception? innerException)
    : UserException("Unexpected error occurred during user operation", innerException);
    
public class UserBlockedException(string email)
    : UserException($"User {email} is blocked and cannot perform this action");